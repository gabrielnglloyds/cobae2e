package steps;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import org.junit.Assert;

public class BusinessCustomerJourney {
    @Given("Get Call to {string}")
    public void getCallTo(String arg0) {
        System.out.println(arg0);

//        RestAssured.baseURI = TestRunner.addItemListApiUrl;
//        return RestAssured.given()
//                .header("x-adq-correlation-id", "234eef-33df-w4v42-adfr335fs")
//                .header("Content-Type", "application/json")
//                .body(body.toString())
//                .post("api/v1/");
    }

    @Then("Response Code {string} is validated")
    public void responseCodeIsValidated(String arg0) {
        Assert.assertEquals(2,3);

    }

    @Then("Response  is array total {string}")
    public void responseIsArrayTotal(String arg0) {
        System.out.println(arg0);

    }
}
