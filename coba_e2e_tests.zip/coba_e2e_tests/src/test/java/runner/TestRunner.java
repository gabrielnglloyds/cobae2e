package runner;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = {"src/test/resources/features"},
        glue = {"steps"},
        monochrome = true,
        dryRun = false,
        tags = ("@smoke"),
        plugin = {
//                "usage",
                "json:build/cucumber-reports/cucumber.json",
                "rerun:build/cucumber-reports/rerun.txt",
                "html:build/cucumber-reports/index.html"
        })
public class TestRunner {
}